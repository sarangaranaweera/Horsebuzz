/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
@author translation: Davide Montorio
*/
CKEDITOR.plugins.setLang('wordcount', 'it', {
    WordCount: 'Parole:',
    CharCount: 'Caratteri:',
    CharCountWithHTML: 'Caratteri (HTML incluso):',
    Paragraphs: 'Paragraphs:',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statistiche'
});
